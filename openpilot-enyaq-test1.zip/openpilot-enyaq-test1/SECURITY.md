# Security Policy

## Reporting a Vulnerability

Suspected vulnerabilities can be reported to both `adeeb@comma.ai` and `security@comma.ai`.
