# Replay

Replaying is a critical tool for openpilot development and debugging.

## Replaying a route
*Hardware required: none*

Just run `tools/replay/replay --demo`.

## Replaying CAN data
*Hardware required: jungle and comma 3/3X*

1. Connect your PC to a jungle.
2.
