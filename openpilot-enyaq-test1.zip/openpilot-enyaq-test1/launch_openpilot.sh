#!/usr/bin/env bash

exec ./launch_chffrplus.sh
