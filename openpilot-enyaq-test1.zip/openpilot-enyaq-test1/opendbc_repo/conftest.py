# pytest attempts to execute shell scripts while collecting
collect_ignore_glob = [
  "opendbc/safety/tests/misra/*",
]
